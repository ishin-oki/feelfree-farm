// 公開前の設定。価格・数量は仮。Instagram URLは公式アカウント確認後に設定。
window.FARM_CONFIG = { price: 300, maxBags: 5, instagramUrl: '' };
